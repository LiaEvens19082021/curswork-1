﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Sale
    {
        public int Id;
        public int ClientId;
        public int ProductId;
        public DateTime Date;
        public int Quantity;
        public decimal Total;
    }
}
