﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Product
    {
        public int Id;
        public string Name;
        public int CategoryId;
        public decimal Price;
        public int Stock;
        public int ProviderId;
    }
}
